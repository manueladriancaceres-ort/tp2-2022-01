class Cliente {
    constructor(nombre, documento) {
        this.nombre = nombre;
        this.documento = documento;
    }
}
export default Cliente;
