class Cliente {

    nombre: string         // private String nombre;
    documento: number      // private int documento;
    
    constructor(nombre: string, documento: number) {
        this.nombre = nombre;
        this.documento = documento;
    }
    
}

export default Cliente